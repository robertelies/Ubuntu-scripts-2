#!/bin/bash

# Loop through the series names
for series_name in "$@"; do
# Create a directory for the series if it doesn't exist
    if [ ! -d "$series_name" ]; then
        mkdir "$series_name"
    fi

# Construct the URL to search for the series on EZTV
    search_url="http://eztv.it/search/$series_name/"

# Download the HTML page containing search results
    wget -q -O "$series_name/search_results.html" "$search_url"

# Extract the download links from the search results
    download_links=$(grep -o -E "http://eztv.it/.*$series_name[^']+" "$series_name/search_results.html" | awk '!a[$0]++')

# Loop through the download links and download the torrents
    download_count=1
    for link in $download_links; do
        echo "Download $download_count: $link"
        wget -P "$series_name" "$link"
        download_count=$((download_count + 1))
    done

# Removing the search results HTML file (the clean up)
    rm "$series_name/search_results.html"

    echo "Downloaded all torrents for '$series_name'"
done

