#!/bin/bash

# Asking for the file
echo "Enter the name of the file:"
read filename

# Check if file exists
if [ ! -f "$filename" ]; then
    echo "File does not exist."
    exit 1
fi

# Count the total number of lines
total_lines=$(wc -l < "$filename")

# Display the total number of lines
echo "Total number of lines in $filename: $total_lines"

# Asking for line num
echo "Enter the line number you want to display (1-$total_lines):"
read line_number

# Read and display selected line
line_content=$(sed -n "${line_number}p" "$filename")
echo "Line $line_number: $line_content"

