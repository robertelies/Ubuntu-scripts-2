#!/bin/bash

# Asking phrase
echo "Enter a phrase:"
read phrase

# Asking letter
echo "Enter a letter to count:"
read letter

count=0

# Get the length of the phrase
phrase_length="${#phrase}"

for ((i = 0; i < phrase_length; i++)); do
    current_char="${phrase:i:1}"
# Check if the current character is the specified letter
    if [ "${current_char,,}" = "${letter,,}" ]; then
        count=$((count + 1))
    fi
done

# Printing the count
echo "The letter '$letter' appears $count times in the phrase."

