#!/bin/bash

# Function to convert a number to Roman numerals
toRoman() {
    local num=$1
    local val=("M" "CM" "D" "CD" "C" "XC" "L" "XL" "X" "IX" "V" "IV" "I")
    local numvals=(1000 900 500 400 100 90 50 40 10 9 5 4 1)
    local result=""

    if ((num < 1 || num > 3999)); then
        echo "Error: Input number must be in the range [1, 3999]."
        return 1
    fi

    for ((i = 0; i < ${#numvals[@]}; i++)); do
        while ((num >= numvals[i])); do
            result="${result}${val[i]}"
            num=$((num - numvals[i]))
        done
    done
    echo "$result"
}

input_number=$1

converted_number=$(toRoman "$input_number")
if [ $? -eq 0 ]; then
    echo "Roman numeral for $input_number is: $converted_number"
fi

