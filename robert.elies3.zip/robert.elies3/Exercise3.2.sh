#!/bin/bash

username="$1"

# Getting all the processes owned by the specified username
process_list=$(ps -u "$username" -o pid,pcpu,%mem)

# Total CPU and memory usage vars
total_cpu_usage=0
total_mem_usage=0

# Loop through the process list and sum up CPU and memory usage
while read -r line; do
    pid=$(echo "$line" | awk '{print $1}')
    cpu_usage=$(echo "$line" | awk '{print $2}')
    mem_usage=$(echo "$line" | awk '{print $3}')

# Add CPU and memory usage to the totals
    total_cpu_usage=$(awk "BEGIN {print $total_cpu_usage + $cpu_usage}")
    total_mem_usage=$(awk "BEGIN {print $total_mem_usage + $mem_usage}")
done <<< "$process_list"

# Print the total CPU and memory usage
echo "Total CPU Usage by $username's processes: $total_cpu_usage%"
echo "Total Memory Usage by $username's processes: $total_mem_usage%"

